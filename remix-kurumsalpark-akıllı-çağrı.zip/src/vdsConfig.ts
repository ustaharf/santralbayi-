export const VDS_HOST = '178.208.187.42';
export const VDS_WEB_ORIGIN = `http://${VDS_HOST}:3000`;
export const VDS_PBX_API_ORIGIN = `http://${VDS_HOST}:8000`;

export function resolveServerApiUrl(path: string): string {
  if (typeof window !== 'undefined') {
    const h = window.location.hostname;
    const p = window.location.port;
    if ((h === 'localhost' || h === '127.0.0.1') && (!p || p === '80' || p === '443')) {
      return `${VDS_WEB_ORIGIN}${path}`;
    }
  }
  return path;
}
