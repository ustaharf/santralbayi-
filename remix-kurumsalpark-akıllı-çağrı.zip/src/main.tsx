import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Capacitor, SystemBars, SystemBarsStyle } from '@capacitor/core';
import App from './App.tsx';
import { VDS_HOST, VDS_WEB_ORIGIN } from './vdsConfig';
import './index.css';

// Canlı VDS Oturum Aktarımı: Cihazdaki giriş oturumunu koruyarak VDS üzerindeki en güncel sürümü açar
try {
  const urlObj = new URL(window.location.href);
  const incomingSession = urlObj.searchParams.get('sb_ota_session');
  if (incomingSession) {
    if (!localStorage.getItem('sb_active_auth_session_v1')) {
      localStorage.setItem('sb_active_auth_session_v1', decodeURIComponent(incomingSession));
    }
    urlObj.searchParams.delete('sb_ota_session');
    window.history.replaceState({}, '', urlObj.toString());
  }
} catch {}

const checkAndApplyLiveUpdate = () => {
  if (window.location.hostname === VDS_HOST) {
    try {
      if (localStorage.getItem('sb_force_ota_refresh_v1') === '1') {
        localStorage.removeItem('sb_force_ota_refresh_v1');
        window.location.reload();
      }
    } catch {}
    return;
  }

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 2500);

  fetch(`${VDS_WEB_ORIGIN}/api/server-meta?t=${Date.now()}`, {
    cache: 'no-store',
    signal: ctrl.signal,
  })
    .then((res) => (res.ok ? res.json() : null))
    .then((meta) => {
      if (meta && meta.ok) {
        try {
          localStorage.removeItem('sb_force_ota_refresh_v1');
        } catch {}
        const savedSession = localStorage.getItem('sb_active_auth_session_v1');
        const sessionParam = savedSession
          ? `&sb_ota_session=${encodeURIComponent(savedSession)}`
          : '';
        window.location.replace(`${VDS_WEB_ORIGIN}/?v=${meta.buildTime || Date.now()}${sessionParam}`);
      }
    })
    .catch(() => {
      // Sunucu bakımda veya internet yoksa APK yerel paketle kesintisiz çalışmaya devam eder
    })
    .finally(() => {
      clearTimeout(timer);
    });
};

if (Capacitor.isNativePlatform()) {
  SystemBars.setStyle({ style: SystemBarsStyle.Dark }).catch(() => {});
  SystemBars.show().catch(() => {});

  checkAndApplyLiveUpdate();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      SystemBars.setStyle({ style: SystemBarsStyle.Dark }).catch(() => {});
      checkAndApplyLiveUpdate();
    }
  });
}

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}
