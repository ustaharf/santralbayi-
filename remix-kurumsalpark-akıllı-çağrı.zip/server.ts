import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import net from 'net';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, GenerateContentResponse, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SERVER_BOOT_TIME = Date.now();
let currentVoiceVersion = 'natural3';

function checkTcpPort(host: string, port: number, timeoutMs = 1500): Promise<boolean> {
  return new Promise((resolve) => {
    const socket = net.connect({ host, port, timeout: timeoutMs });
    socket.on('connect', () => {
      socket.destroy();
      resolve(true);
    });
    socket.on('timeout', () => {
      socket.destroy();
      resolve(false);
    });
    socket.on('error', () => {
      socket.destroy();
      resolve(false);
    });
  });
}

function getAiClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.sendStatus(204);
      return;
    }
    next();
  });

  app.use(express.json({ limit: '50mb' }));

  app.get('/api/server-meta', (_req, res) => {
    res.json({
      ok: true,
      serverIp: '178.208.187.42',
      buildTime: SERVER_BOOT_TIME,
      voiceVersion: currentVoiceVersion,
      pbxSipPort: 5060,
    });
  });

  app.get('/api/pbx/status', async (_req, res) => {
    const [sipInternalOpen, sipExternalOpen, postgresOpen] = await Promise.all([
      checkTcpPort('127.0.0.1', 5060),
      checkTcpPort('127.0.0.1', 5080),
      checkTcpPort('127.0.0.1', 5432),
    ]);

    let asistanApi: Record<string, unknown> | null = null;
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 2000);
      const r = await fetch('http://127.0.0.1:8000/', { signal: ctrl.signal });
      clearTimeout(t);
      if (r.ok) {
        asistanApi = (await r.json()) as Record<string, unknown>;
      }
    } catch {
      asistanApi = null;
    }

    res.json({
      ok: sipInternalOpen && Boolean(asistanApi),
      serverIp: '178.208.187.42',
      fusionPbxSipInternal: sipInternalOpen,
      fusionPbxSipExternal: sipExternalOpen,
      postgresDatabase: postgresOpen,
      kenanAsistanApi: asistanApi,
    });
  });

  app.get('/api/pbx/check-caller/:telefon', async (req, res) => {
    try {
      const tel = encodeURIComponent(req.params.telefon || '');
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 3000);
      const r = await fetch(`http://127.0.0.1:8000/check-caller/${tel}`, { signal: ctrl.signal });
      clearTimeout(t);
      const data = await r.json().catch(() => ({}));
      res.status(r.status).json(data);
    } catch (err: any) {
      res.status(502).json({ error: err?.message || 'FusionPBX / Asistan API bağlantı hatası' });
    }
  });

  app.post('/api/gemini/generate', async (req, res) => {
    try {
      const { prompt, systemInstruction, responseMimeType } = req.body || {};
      if (!prompt || typeof prompt !== 'string') {
        res.status(400).json({ error: 'Missing prompt' });
        return;
      }

      const ai = getAiClient();
      const config: Record<string, unknown> = {
        thinkingConfig: thinkingLevelConfig(),
      };
      if (systemInstruction) {
        config.systemInstruction = systemInstruction;
      }
      if (responseMimeType) {
        config.responseMimeType = responseMimeType;
      }

      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config,
      });

      res.json({ text: response.text ?? '' });
    } catch (error: any) {
      console.error('Gemini API error:', error);
      res.status(error?.status || 500).json({
        error: error?.message || 'Failed to generate content from Gemini API',
      });
    }
  });

  app.post('/api/voice/upload', async (req, res) => {
    try {
      const { audioDataUrl } = req.body || {};
      if (!audioDataUrl || typeof audioDataUrl !== 'string') {
        res.status(400).json({ error: 'Geçersiz ses verisi' });
        return;
      }
      const base64Match = audioDataUrl.match(/^data:[^;]+;base64,(.+)$/);
      if (base64Match && base64Match[1]) {
        const buffer = Buffer.from(base64Match[1], 'base64');
        const targetDir = path.join(__dirname, 'public', 'assets', 'aistudio');
        fs.mkdirSync(targetDir, { recursive: true });
        const targetFile = path.join(targetDir, 'sekreter_ornek_ses.mp3');
        fs.writeFileSync(targetFile, buffer);
        currentVoiceVersion = `v_${Date.now()}`;
      }
      res.json({
        ok: true,
        audioUrl: `/assets/aistudio/sekreter_ornek_ses.mp3?v=${currentVoiceVersion}`,
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Ses dosyası kaydedilemedi' });
    }
  });

  app.post('/api/tts', async (_req, res) => {
    res.json({
      audioDataUrl: `/assets/aistudio/sekreter_ornek_ses.mp3?v=${currentVoiceVersion}`,
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

function thinkingLevelConfig() {
  return { thinkingLevel: ThinkingLevel.LOW };
}

startServer();
